from django.urls import path
from . import views

urlpatterns = [
    path('', views.url_shortener_view, name='url_shortener'),
    path('<str:short_key>/', views.redirect_view, name='redirect'),
]
