from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import ShortURL, IPBlacklist
from .forms import URLForm, AntiSpamConfigForm
from django.http import HttpResponse
from django.contrib import messages
import datetime


request_counts = {}



def url_shortener_view(request):
    
    url_form = URLForm()  
    config_form = AntiSpamConfigForm(initial=request.session.get('config', {}))

   
    if 'config' in request.POST:
        config_form = AntiSpamConfigForm(request.POST)
        if config_form.is_valid():
            request.session['max_requests'] = config_form.cleaned_data['max_requests']
            request.session['time_frame'] = config_form.cleaned_data['time_frame']
            request.session['block_duration'] = config_form.cleaned_data['block_duration']
            messages.success(request, "Anti-spam settings updated.")
    
 
    elif 'url' in request.POST:
        url_form = URLForm(request.POST)
        if url_form.is_valid():
            original_url = url_form.cleaned_data['original_url']
            client_ip = get_client_ip(request)

         
            if is_ip_blocked(client_ip):
                messages.error(request, "You are temporarily blocked. Please try again later.")
            else:
             
                short_url = ShortURL.objects.create(original_url=original_url)
                messages.success(request, f"Shortened URL: http://localhost:8000/{short_url.short_key}")
                increment_request_count(client_ip, request)

    context = {
        'url_form': url_form,
        'config_form': config_form,
    }
    return render(request, 'templates/shorten.html', context)

def redirect_view(request, short_key):
    short_url = get_object_or_404(ShortURL, short_key=short_key)
    short_url.last_accessed = timezone.now()
    short_url.save()
    return redirect(short_url.original_url)

def is_ip_blocked(ip_address):
    blacklist_entry = IPBlacklist.objects.filter(ip_address=ip_address).first()
    return blacklist_entry and blacklist_entry.is_blocked()

def increment_request_count(ip, request):
    max_requests = request.session.get('max_requests', 3)
    time_frame = request.session.get('time_frame', 60)
    block_duration = request.session.get('block_duration', 300)
    
    now = timezone.now()
    request_counts[ip] = [t for t in request_counts.get(ip, []) if t > now - datetime.timedelta(seconds=time_frame)]
    request_counts[ip].append(now)

 
    if len(request_counts[ip]) > max_requests:
        IPBlacklist.objects.update_or_create(
            ip_address=ip,
            defaults={'blocked_until': now + datetime.timedelta(seconds=block_duration)}
        )
        del request_counts[ip]

def get_client_ip(request):
    return request.META.get('REMOTE_ADDR')
