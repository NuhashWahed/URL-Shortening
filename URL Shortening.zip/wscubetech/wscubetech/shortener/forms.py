from django import forms

class URLForm(forms.Form):
    original_url = forms.URLField(label="Enter URL", required=True)

class AntiSpamConfigForm(forms.Form):
    max_requests = forms.IntegerField(label="Max Requests per IP", initial=3)
    time_frame = forms.IntegerField(label="Time Frame (seconds)", initial=60)
    block_duration = forms.IntegerField(label="Block Duration (seconds)", initial=300)
