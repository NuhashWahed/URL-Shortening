from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render



